﻿////////////////////////////////////////////////////////////////////////////////
//  
// @module Android Native Plugin for Unity3D 
// @author Osipov Stanislav (Stan's Assets) 
// @support stans.assets@gmail.com 
//
////////////////////////////////////////////////////////////////////////////////

using UnityEngine;
using System.Collections;



namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Google Analytics")]
	public class GA_SocialHit : FsmStateAction {


		public FsmString action;
		public FsmString network;
		public FsmString target;



		public override void OnEnter() {
			SA.Analytics.Google.GA_Manager.Client.SendSocialHit(action.Value, network.Value, target.Value);
			Finish();

		}

		
	}
}
