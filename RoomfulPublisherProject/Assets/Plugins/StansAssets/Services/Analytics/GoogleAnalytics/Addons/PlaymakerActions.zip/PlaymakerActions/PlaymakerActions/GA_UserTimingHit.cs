﻿////////////////////////////////////////////////////////////////////////////////
//  
// @module Android Native Plugin for Unity3D 
// @author Osipov Stanislav (Stan's Assets) 
// @support stans.assets@gmail.com 
//
////////////////////////////////////////////////////////////////////////////////

using UnityEngine;
using System.Collections;



namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Google Analytics")]
	public class GA_UserTimingHit : FsmStateAction {


		public FsmString category;
		public FsmString variable;
		public FsmInt time;
		public FsmString label;



		public override void OnEnter() {
			SA.Analytics.Google.GA_Manager.Client.SendUserTimingHit(category.Value, variable.Value, time.Value, label.Value);
			Finish();

		}

	}
}
