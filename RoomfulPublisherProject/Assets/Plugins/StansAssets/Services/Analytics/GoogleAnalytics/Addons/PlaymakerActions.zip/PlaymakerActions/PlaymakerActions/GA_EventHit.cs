﻿////////////////////////////////////////////////////////////////////////////////
//  
// @module Android Native Plugin for Unity3D 
// @author Osipov Stanislav (Stan's Assets) 
// @support stans.assets@gmail.com 
//
////////////////////////////////////////////////////////////////////////////////

using UnityEngine;
using System.Collections;



namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Google Analytics")]
	public class GA_EventHit : FsmStateAction {


		public FsmString category;
		public FsmString action;
		public FsmString label;

		public FsmBool sendValue;
		public FsmInt val;



		public override void OnEnter() {
			if(sendValue.Value) {
				SA.Analytics.Google.GA_Manager.Client.SendEventHit(category.Value, action.Value, label.Value, val.Value);
			} else {
				SA.Analytics.Google.GA_Manager.Client.SendEventHit(category.Value, action.Value, label.Value, -1);
			}

			Finish();

		}

		
	}
}
