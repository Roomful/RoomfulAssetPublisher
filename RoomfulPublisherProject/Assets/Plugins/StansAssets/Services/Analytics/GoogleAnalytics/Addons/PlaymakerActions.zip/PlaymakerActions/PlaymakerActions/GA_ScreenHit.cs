﻿////////////////////////////////////////////////////////////////////////////////
//  
// @module Android Native Plugin for Unity3D 
// @author Osipov Stanislav (Stan's Assets) 
// @support stans.assets@gmail.com 
//
////////////////////////////////////////////////////////////////////////////////

using UnityEngine;
using System.Collections;



namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Google Analytics")]
	public class GA_ScreenHit : FsmStateAction {


		public FsmString screenName;
	



		public override void OnEnter() {
			SA.Analytics.Google.GA_Manager.Client.SendScreenHit(screenName.Value);
			Finish();

		}

	}
}
